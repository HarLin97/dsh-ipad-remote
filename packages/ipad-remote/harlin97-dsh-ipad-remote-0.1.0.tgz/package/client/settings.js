window.__ModuleLoader__.load({
	id: "@harlin97/dsh-ipad-remote",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react = require("react");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		//#region src/client/picker-flow.ts
		/**
		* Register the workspace directory flow only where it can actually run.
		*
		* Upstream picks one directory-picker backend per boot, and that single choice
		* serves both the desktop shell and every remote browser:
		* - the official adaptive chooser mounts the native surface, which uses the
		*   Electron bridge when the page has it and otherwise asks the host — so on a
		*   phone the system window opens on the PC screen, where nobody can reach it;
		* - pinning the browsing surface instead moves the desktop off its own window.
		*
		* This deployment wants the desktop system window AND no unusable offer on a
		* remote client. ui-workspace decides that offer by asking whether anybody
		* occupies the directory-flow slot, so the decision can be made per PAGE instead
		* of per boot: the Electron shell exposes `__DSH_DIRECTORY_PICKER__`, a browser
		* does not, and registering NOTHING is what removes the entry.
		* @module @harlin97/dsh-ipad-remote/client/picker-flow
		*/
		/** Global the desktop shell preloads; absent in every browser. */
		const DIRECTORY_BRIDGE_GLOBAL = "__DSH_DIRECTORY_PICKER__";
		/**
		* Read the desktop bridge from a global scope.
		* @param scope - object to inspect; defaults to the page global, injectable for tests.
		* @returns the bridge, or undefined in any browser.
		*/
		function desktopBridge(scope = globalThis) {
			const candidate = scope[DIRECTORY_BRIDGE_GLOBAL];
			if (typeof candidate !== "object" || candidate === null) return void 0;
			const pick = candidate.pick;
			if (typeof pick !== "function") return void 0;
			return { pick };
		}
		/**
		* Renderless occupant: one pick per rising `open` edge, one outcome reported.
		*
		* The shape mirrors the upstream native occupant, because that is what the
		* ui-workspace owner drives: it raises `open`, then expects exactly one of
		* onPicked / onCancel / onError.
		* @param props - owner props plus the injected pick.
		* @returns nothing; the system window renders on this machine display.
		*/
		function DesktopDirectoryFlow(props) {
			const { open, pick } = props;
			const armed = (0, react.useRef)(false);
			const outcome = (0, react.useRef)(props);
			outcome.current = props;
			const alive = (0, react.useRef)(true);
			(0, react.useEffect)(() => {
				alive.current = true;
				return () => {
					alive.current = false;
				};
			}, []);
			(0, react.useEffect)(() => {
				if (!open) {
					armed.current = false;
					return;
				}
				if (armed.current) return;
				armed.current = true;
				pick().then((path) => {
					if (!alive.current) return;
					if (path === null) outcome.current.onCancel();
					else outcome.current.onPicked(path);
				}, (reason) => {
					if (!alive.current) return;
					outcome.current.onError(reason instanceof Error ? reason.message : String(reason));
				});
			}, [open, pick]);
			return null;
		}
		/**
		* Occupy both directory-flow slots when the desktop bridge exists.
		*
		* A browser registers nothing on purpose. With the slot empty, ui-workspace
		* reports the flow as unavailable and never renders the "add workspace" entry,
		* so a remote client picks among workspaces that already exist — which is the
		* whole of what choosing a folder remotely can be here.
		* @param ctx - owning client plugin context.
		*/
		function installDirectoryFlow(ctx) {
			const bridge = desktopBridge();
			if (bridge === void 0) return;
			const pick = () => bridge.pick();
			const injected = () => ({ pick });
			ctx.slots.inject("conversation.hero.workspace.directoryFlow", () => ctx.slots.inject("sidebar.workspaces.directoryFlow", function* () {
				yield ctx.slots.register({
					name: "conversation.hero.workspace.directoryFlow",
					inject: injected
				}, DesktopDirectoryFlow);
				yield ctx.slots.register({
					name: "sidebar.workspaces.directoryFlow",
					inject: injected
				}, DesktopDirectoryFlow);
			}));
		}
		//#endregion
		//#region src/contract.ts
		/** Loopback control surface used by the Harness settings card. */
		const CONTROL_PREFIX = "/ipad-remote/api";
		/**
		* Whether a candidate PIN has the accepted shape (exactly {@link PIN_LENGTH} digits).
		*
		* The Host enforces this on every write; the settings card validates with the
		* same function so the user sees the error before a round trip.
		* @param pin - candidate.
		* @returns true when the PIN is well-formed.
		*/
		function isValidPinFormat(pin) {
			return new RegExp(`^[0-9]{${String(6)}}$`).test(pin);
		}
		//#endregion
		//#region src/client/api.ts
		/**
		* Control-surface client used by the settings section.
		*
		* Every call goes to the loopback surface the Host registers on the Harness
		* webserver, so the browser is same-origin and \`sameOrigin()\` accepts the
		* writes. The fetch face is injectable so the section can be tested without a
		* network.
		* @module @harlin97/dsh-ipad-remote/client/api
		*/
		/**
		* Extract a human-readable message from a thrown value.
		* @param error - anything thrown.
		* @returns the message, or a generic fallback.
		*/
		function messageOf(error) {
			return error instanceof Error && error.message !== "" ? error.message : String(error);
		}
		/**
		* Build a control client.
		* @param fetchImpl - fetch implementation; defaults to the global one.
		* @param prefix - control-surface prefix; defaults to the wire constant.
		* @returns the client.
		*/
		function createControlApi(fetchImpl = globalThis.fetch, prefix = CONTROL_PREFIX) {
			const request = async (path, body) => {
				const init = body === void 0 ? {} : {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify(body)
				};
				const response = await fetchImpl(prefix + path, init);
				let payload;
				try {
					payload = await response.json();
				} catch {
					payload = void 0;
				}
				if (!response.ok) {
					const reported = payload?.error;
					throw new Error(typeof reported === "string" && reported !== "" ? reported : `HTTP ${String(response.status)}`);
				}
				return payload;
			};
			return {
				status: () => request("/status"),
				setEnabled: (enabled) => request("/enable", { enabled }),
				setPin: (pin) => request("/pin", { pin }),
				revoke: () => request("/revoke", {})
			};
		}
		//#endregion
		//#region src/client/vendor/qrcode-generator.ts
		/**
		* Vendored: qrcode-generator 1.4.4 (https://unpkg.com/qrcode-generator@1.4.4/qrcode.js)
		* Copyright (c) 2009 Kazuhiko Arase — MIT licensed, license header retained below.
		*
		* Vendored verbatim except: the trailing UMD/AMD wrapper was removed and an
		* ESM default export appended, so the module can be inlined into the plugin's
		* browser bundle and imported by the Node-side tests. 'QR Code' is a registered
		* trademark of DENSO WAVE INCORPORATED.
		*/
		var qrcode = function() {
			/**
			* qrcode
			* @param typeNumber 1 to 40
			* @param errorCorrectionLevel 'L','M','Q','H'
			*/
			var qrcode = function(typeNumber, errorCorrectionLevel) {
				var PAD0 = 236;
				var PAD1 = 17;
				var _typeNumber = typeNumber;
				var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
				var _modules = null;
				var _moduleCount = 0;
				var _dataCache = null;
				var _dataList = [];
				var _this = {};
				var makeImpl = function(test, maskPattern) {
					_moduleCount = _typeNumber * 4 + 17;
					_modules = function(moduleCount) {
						var modules = new Array(moduleCount);
						for (var row = 0; row < moduleCount; row += 1) {
							modules[row] = new Array(moduleCount);
							for (var col = 0; col < moduleCount; col += 1) modules[row][col] = null;
						}
						return modules;
					}(_moduleCount);
					setupPositionProbePattern(0, 0);
					setupPositionProbePattern(_moduleCount - 7, 0);
					setupPositionProbePattern(0, _moduleCount - 7);
					setupPositionAdjustPattern();
					setupTimingPattern();
					setupTypeInfo(test, maskPattern);
					if (_typeNumber >= 7) setupTypeNumber(test);
					if (_dataCache == null) _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
					mapData(_dataCache, maskPattern);
				};
				var setupPositionProbePattern = function(row, col) {
					for (var r = -1; r <= 7; r += 1) {
						if (row + r <= -1 || _moduleCount <= row + r) continue;
						for (var c = -1; c <= 7; c += 1) {
							if (col + c <= -1 || _moduleCount <= col + c) continue;
							if (0 <= r && r <= 6 && (c == 0 || c == 6) || 0 <= c && c <= 6 && (r == 0 || r == 6) || 2 <= r && r <= 4 && 2 <= c && c <= 4) _modules[row + r][col + c] = true;
							else _modules[row + r][col + c] = false;
						}
					}
				};
				var getBestMaskPattern = function() {
					var minLostPoint = 0;
					var pattern = 0;
					for (var i = 0; i < 8; i += 1) {
						makeImpl(true, i);
						var lostPoint = QRUtil.getLostPoint(_this);
						if (i == 0 || minLostPoint > lostPoint) {
							minLostPoint = lostPoint;
							pattern = i;
						}
					}
					return pattern;
				};
				var setupTimingPattern = function() {
					for (var r = 8; r < _moduleCount - 8; r += 1) {
						if (_modules[r][6] != null) continue;
						_modules[r][6] = r % 2 == 0;
					}
					for (var c = 8; c < _moduleCount - 8; c += 1) {
						if (_modules[6][c] != null) continue;
						_modules[6][c] = c % 2 == 0;
					}
				};
				var setupPositionAdjustPattern = function() {
					var pos = QRUtil.getPatternPosition(_typeNumber);
					for (var i = 0; i < pos.length; i += 1) for (var j = 0; j < pos.length; j += 1) {
						var row = pos[i];
						var col = pos[j];
						if (_modules[row][col] != null) continue;
						for (var r = -2; r <= 2; r += 1) for (var c = -2; c <= 2; c += 1) if (r == -2 || r == 2 || c == -2 || c == 2 || r == 0 && c == 0) _modules[row + r][col + c] = true;
						else _modules[row + r][col + c] = false;
					}
				};
				var setupTypeNumber = function(test) {
					var bits = QRUtil.getBCHTypeNumber(_typeNumber);
					for (var i = 0; i < 18; i += 1) {
						var mod = !test && (bits >> i & 1) == 1;
						_modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
					}
					for (var i = 0; i < 18; i += 1) {
						var mod = !test && (bits >> i & 1) == 1;
						_modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
					}
				};
				var setupTypeInfo = function(test, maskPattern) {
					var data = _errorCorrectionLevel << 3 | maskPattern;
					var bits = QRUtil.getBCHTypeInfo(data);
					for (var i = 0; i < 15; i += 1) {
						var mod = !test && (bits >> i & 1) == 1;
						if (i < 6) _modules[i][8] = mod;
						else if (i < 8) _modules[i + 1][8] = mod;
						else _modules[_moduleCount - 15 + i][8] = mod;
					}
					for (var i = 0; i < 15; i += 1) {
						var mod = !test && (bits >> i & 1) == 1;
						if (i < 8) _modules[8][_moduleCount - i - 1] = mod;
						else if (i < 9) _modules[8][15 - i - 1 + 1] = mod;
						else _modules[8][15 - i - 1] = mod;
					}
					_modules[_moduleCount - 8][8] = !test;
				};
				var mapData = function(data, maskPattern) {
					var inc = -1;
					var row = _moduleCount - 1;
					var bitIndex = 7;
					var byteIndex = 0;
					var maskFunc = QRUtil.getMaskFunction(maskPattern);
					for (var col = _moduleCount - 1; col > 0; col -= 2) {
						if (col == 6) col -= 1;
						while (true) {
							for (var c = 0; c < 2; c += 1) if (_modules[row][col - c] == null) {
								var dark = false;
								if (byteIndex < data.length) dark = (data[byteIndex] >>> bitIndex & 1) == 1;
								if (maskFunc(row, col - c)) dark = !dark;
								_modules[row][col - c] = dark;
								bitIndex -= 1;
								if (bitIndex == -1) {
									byteIndex += 1;
									bitIndex = 7;
								}
							}
							row += inc;
							if (row < 0 || _moduleCount <= row) {
								row -= inc;
								inc = -inc;
								break;
							}
						}
					}
				};
				var createBytes = function(buffer, rsBlocks) {
					var offset = 0;
					var maxDcCount = 0;
					var maxEcCount = 0;
					var dcdata = new Array(rsBlocks.length);
					var ecdata = new Array(rsBlocks.length);
					for (var r = 0; r < rsBlocks.length; r += 1) {
						var dcCount = rsBlocks[r].dataCount;
						var ecCount = rsBlocks[r].totalCount - dcCount;
						maxDcCount = Math.max(maxDcCount, dcCount);
						maxEcCount = Math.max(maxEcCount, ecCount);
						dcdata[r] = new Array(dcCount);
						for (var i = 0; i < dcdata[r].length; i += 1) dcdata[r][i] = 255 & buffer.getBuffer()[i + offset];
						offset += dcCount;
						var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
						var modPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1).mod(rsPoly);
						ecdata[r] = new Array(rsPoly.getLength() - 1);
						for (var i = 0; i < ecdata[r].length; i += 1) {
							var modIndex = i + modPoly.getLength() - ecdata[r].length;
							ecdata[r][i] = modIndex >= 0 ? modPoly.getAt(modIndex) : 0;
						}
					}
					var totalCodeCount = 0;
					for (var i = 0; i < rsBlocks.length; i += 1) totalCodeCount += rsBlocks[i].totalCount;
					var data = new Array(totalCodeCount);
					var index = 0;
					for (var i = 0; i < maxDcCount; i += 1) for (var r = 0; r < rsBlocks.length; r += 1) if (i < dcdata[r].length) {
						data[index] = dcdata[r][i];
						index += 1;
					}
					for (var i = 0; i < maxEcCount; i += 1) for (var r = 0; r < rsBlocks.length; r += 1) if (i < ecdata[r].length) {
						data[index] = ecdata[r][i];
						index += 1;
					}
					return data;
				};
				var createData = function(typeNumber, errorCorrectionLevel, dataList) {
					var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);
					var buffer = qrBitBuffer();
					for (var i = 0; i < dataList.length; i += 1) {
						var data = dataList[i];
						buffer.put(data.getMode(), 4);
						buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber));
						data.write(buffer);
					}
					var totalDataCount = 0;
					for (var i = 0; i < rsBlocks.length; i += 1) totalDataCount += rsBlocks[i].dataCount;
					if (buffer.getLengthInBits() > totalDataCount * 8) throw "code length overflow. (" + buffer.getLengthInBits() + ">" + totalDataCount * 8 + ")";
					if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) buffer.put(0, 4);
					while (buffer.getLengthInBits() % 8 != 0) buffer.putBit(false);
					while (true) {
						if (buffer.getLengthInBits() >= totalDataCount * 8) break;
						buffer.put(PAD0, 8);
						if (buffer.getLengthInBits() >= totalDataCount * 8) break;
						buffer.put(PAD1, 8);
					}
					return createBytes(buffer, rsBlocks);
				};
				_this.addData = function(data, mode) {
					mode = mode || "Byte";
					var newData = null;
					switch (mode) {
						case "Numeric":
							newData = qrNumber(data);
							break;
						case "Alphanumeric":
							newData = qrAlphaNum(data);
							break;
						case "Byte":
							newData = qr8BitByte(data);
							break;
						case "Kanji":
							newData = qrKanji(data);
							break;
						default: throw "mode:" + mode;
					}
					_dataList.push(newData);
					_dataCache = null;
				};
				_this.isDark = function(row, col) {
					if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) throw row + "," + col;
					return _modules[row][col];
				};
				_this.getModuleCount = function() {
					return _moduleCount;
				};
				_this.make = function() {
					if (_typeNumber < 1) {
						var typeNumber = 1;
						for (; typeNumber < 40; typeNumber++) {
							var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
							var buffer = qrBitBuffer();
							for (var i = 0; i < _dataList.length; i++) {
								var data = _dataList[i];
								buffer.put(data.getMode(), 4);
								buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber));
								data.write(buffer);
							}
							var totalDataCount = 0;
							for (var i = 0; i < rsBlocks.length; i++) totalDataCount += rsBlocks[i].dataCount;
							if (buffer.getLengthInBits() <= totalDataCount * 8) break;
						}
						_typeNumber = typeNumber;
					}
					makeImpl(false, getBestMaskPattern());
				};
				_this.createTableTag = function(cellSize, margin) {
					cellSize = cellSize || 2;
					margin = typeof margin == "undefined" ? cellSize * 4 : margin;
					var qrHtml = "";
					qrHtml += "<table style=\"";
					qrHtml += " border-width: 0px; border-style: none;";
					qrHtml += " border-collapse: collapse;";
					qrHtml += " padding: 0px; margin: " + margin + "px;";
					qrHtml += "\">";
					qrHtml += "<tbody>";
					for (var r = 0; r < _this.getModuleCount(); r += 1) {
						qrHtml += "<tr>";
						for (var c = 0; c < _this.getModuleCount(); c += 1) {
							qrHtml += "<td style=\"";
							qrHtml += " border-width: 0px; border-style: none;";
							qrHtml += " border-collapse: collapse;";
							qrHtml += " padding: 0px; margin: 0px;";
							qrHtml += " width: " + cellSize + "px;";
							qrHtml += " height: " + cellSize + "px;";
							qrHtml += " background-color: ";
							qrHtml += _this.isDark(r, c) ? "#000000" : "#ffffff";
							qrHtml += ";";
							qrHtml += "\"/>";
						}
						qrHtml += "</tr>";
					}
					qrHtml += "</tbody>";
					qrHtml += "</table>";
					return qrHtml;
				};
				_this.createSvgTag = function(cellSize, margin, alt, title) {
					var opts = {};
					if (typeof arguments[0] == "object") {
						opts = arguments[0];
						cellSize = opts.cellSize;
						margin = opts.margin;
						alt = opts.alt;
						title = opts.title;
					}
					cellSize = cellSize || 2;
					margin = typeof margin == "undefined" ? cellSize * 4 : margin;
					alt = typeof alt === "string" ? { text: alt } : alt || {};
					alt.text = alt.text || null;
					alt.id = alt.text ? alt.id || "qrcode-description" : null;
					title = typeof title === "string" ? { text: title } : title || {};
					title.text = title.text || null;
					title.id = title.text ? title.id || "qrcode-title" : null;
					var size = _this.getModuleCount() * cellSize + margin * 2;
					var c, mc, r, mr, qrSvg = "", rect = "l" + cellSize + ",0 0," + cellSize + " -" + cellSize + ",0 0,-" + cellSize + "z ";
					qrSvg += "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\"";
					qrSvg += !opts.scalable ? " width=\"" + size + "px\" height=\"" + size + "px\"" : "";
					qrSvg += " viewBox=\"0 0 " + size + " " + size + "\" ";
					qrSvg += " preserveAspectRatio=\"xMinYMin meet\"";
					qrSvg += title.text || alt.text ? " role=\"img\" aria-labelledby=\"" + escapeXml([title.id, alt.id].join(" ").trim()) + "\"" : "";
					qrSvg += ">";
					qrSvg += title.text ? "<title id=\"" + escapeXml(title.id) + "\">" + escapeXml(title.text) + "</title>" : "";
					qrSvg += alt.text ? "<description id=\"" + escapeXml(alt.id) + "\">" + escapeXml(alt.text) + "</description>" : "";
					qrSvg += "<rect width=\"100%\" height=\"100%\" fill=\"white\" cx=\"0\" cy=\"0\"/>";
					qrSvg += "<path d=\"";
					for (r = 0; r < _this.getModuleCount(); r += 1) {
						mr = r * cellSize + margin;
						for (c = 0; c < _this.getModuleCount(); c += 1) if (_this.isDark(r, c)) {
							mc = c * cellSize + margin;
							qrSvg += "M" + mc + "," + mr + rect;
						}
					}
					qrSvg += "\" stroke=\"transparent\" fill=\"black\"/>";
					qrSvg += "</svg>";
					return qrSvg;
				};
				_this.createDataURL = function(cellSize, margin) {
					cellSize = cellSize || 2;
					margin = typeof margin == "undefined" ? cellSize * 4 : margin;
					var size = _this.getModuleCount() * cellSize + margin * 2;
					var min = margin;
					var max = size - margin;
					return createDataURL(size, size, function(x, y) {
						if (min <= x && x < max && min <= y && y < max) {
							var c = Math.floor((x - min) / cellSize);
							var r = Math.floor((y - min) / cellSize);
							return _this.isDark(r, c) ? 0 : 1;
						} else return 1;
					});
				};
				_this.createImgTag = function(cellSize, margin, alt) {
					cellSize = cellSize || 2;
					margin = typeof margin == "undefined" ? cellSize * 4 : margin;
					var size = _this.getModuleCount() * cellSize + margin * 2;
					var img = "";
					img += "<img";
					img += " src=\"";
					img += _this.createDataURL(cellSize, margin);
					img += "\"";
					img += " width=\"";
					img += size;
					img += "\"";
					img += " height=\"";
					img += size;
					img += "\"";
					if (alt) {
						img += " alt=\"";
						img += escapeXml(alt);
						img += "\"";
					}
					img += "/>";
					return img;
				};
				var escapeXml = function(s) {
					var escaped = "";
					for (var i = 0; i < s.length; i += 1) {
						var c = s.charAt(i);
						switch (c) {
							case "<":
								escaped += "&lt;";
								break;
							case ">":
								escaped += "&gt;";
								break;
							case "&":
								escaped += "&amp;";
								break;
							case "\"":
								escaped += "&quot;";
								break;
							default: escaped += c;
						}
					}
					return escaped;
				};
				var _createHalfASCII = function(margin) {
					var cellSize = 1;
					margin = typeof margin == "undefined" ? cellSize * 2 : margin;
					var size = _this.getModuleCount() * cellSize + margin * 2;
					var min = margin;
					var max = size - margin;
					var y, x, r1, r2, p;
					var blocks = {
						"██": "█",
						"█ ": "▀",
						" █": "▄",
						"  ": " "
					};
					var blocksLastLineNoMargin = {
						"██": "▀",
						"█ ": "▀",
						" █": " ",
						"  ": " "
					};
					var ascii = "";
					for (y = 0; y < size; y += 2) {
						r1 = Math.floor((y - min) / cellSize);
						r2 = Math.floor((y + 1 - min) / cellSize);
						for (x = 0; x < size; x += 1) {
							p = "█";
							if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) p = " ";
							if (min <= x && x < max && min <= y + 1 && y + 1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) p += " ";
							else p += "█";
							ascii += margin < 1 && y + 1 >= max ? blocksLastLineNoMargin[p] : blocks[p];
						}
						ascii += "\n";
					}
					if (size % 2 && margin > 0) return ascii.substring(0, ascii.length - size - 1) + Array(size + 1).join("▀");
					return ascii.substring(0, ascii.length - 1);
				};
				_this.createASCII = function(cellSize, margin) {
					cellSize = cellSize || 1;
					if (cellSize < 2) return _createHalfASCII(margin);
					cellSize -= 1;
					margin = typeof margin == "undefined" ? cellSize * 2 : margin;
					var size = _this.getModuleCount() * cellSize + margin * 2;
					var min = margin;
					var max = size - margin;
					var y, x, r, p;
					var white = Array(cellSize + 1).join("██");
					var black = Array(cellSize + 1).join("  ");
					var ascii = "";
					var line = "";
					for (y = 0; y < size; y += 1) {
						r = Math.floor((y - min) / cellSize);
						line = "";
						for (x = 0; x < size; x += 1) {
							p = 1;
							if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) p = 0;
							line += p ? white : black;
						}
						for (r = 0; r < cellSize; r += 1) ascii += line + "\n";
					}
					return ascii.substring(0, ascii.length - 1);
				};
				_this.renderTo2dContext = function(context, cellSize) {
					cellSize = cellSize || 2;
					var length = _this.getModuleCount();
					for (var row = 0; row < length; row++) for (var col = 0; col < length; col++) {
						context.fillStyle = _this.isDark(row, col) ? "black" : "white";
						context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
					}
				};
				return _this;
			};
			qrcode.stringToBytesFuncs = { "default": function(s) {
				var bytes = [];
				for (var i = 0; i < s.length; i += 1) {
					var c = s.charCodeAt(i);
					bytes.push(c & 255);
				}
				return bytes;
			} };
			qrcode.stringToBytes = qrcode.stringToBytesFuncs["default"];
			/**
			* @param unicodeData base64 string of byte array.
			* [16bit Unicode],[16bit Bytes], ...
			* @param numChars
			*/
			qrcode.createStringToBytes = function(unicodeData, numChars) {
				var unicodeMap = function() {
					var bin = base64DecodeInputStream(unicodeData);
					var read = function() {
						var b = bin.read();
						if (b == -1) throw "eof";
						return b;
					};
					var count = 0;
					var unicodeMap = {};
					while (true) {
						var b0 = bin.read();
						if (b0 == -1) break;
						var b1 = read();
						var b2 = read();
						var b3 = read();
						var k = String.fromCharCode(b0 << 8 | b1);
						unicodeMap[k] = b2 << 8 | b3;
						count += 1;
					}
					if (count != numChars) throw count + " != " + numChars;
					return unicodeMap;
				}();
				var unknownChar = "?".charCodeAt(0);
				return function(s) {
					var bytes = [];
					for (var i = 0; i < s.length; i += 1) {
						var c = s.charCodeAt(i);
						if (c < 128) bytes.push(c);
						else {
							var b = unicodeMap[s.charAt(i)];
							if (typeof b == "number") {
								if ((b & 255) == b) bytes.push(b);
								else {
									bytes.push(b >>> 8);
									bytes.push(b & 255);
								}
							} else bytes.push(unknownChar);
						}
					}
					return bytes;
				};
			};
			var QRMode = {
				MODE_NUMBER: 1,
				MODE_ALPHA_NUM: 2,
				MODE_8BIT_BYTE: 4,
				MODE_KANJI: 8
			};
			var QRErrorCorrectionLevel = {
				L: 1,
				M: 0,
				Q: 3,
				H: 2
			};
			var QRMaskPattern = {
				PATTERN000: 0,
				PATTERN001: 1,
				PATTERN010: 2,
				PATTERN011: 3,
				PATTERN100: 4,
				PATTERN101: 5,
				PATTERN110: 6,
				PATTERN111: 7
			};
			var QRUtil = function() {
				var PATTERN_POSITION_TABLE = [
					[],
					[6, 18],
					[6, 22],
					[6, 26],
					[6, 30],
					[6, 34],
					[
						6,
						22,
						38
					],
					[
						6,
						24,
						42
					],
					[
						6,
						26,
						46
					],
					[
						6,
						28,
						50
					],
					[
						6,
						30,
						54
					],
					[
						6,
						32,
						58
					],
					[
						6,
						34,
						62
					],
					[
						6,
						26,
						46,
						66
					],
					[
						6,
						26,
						48,
						70
					],
					[
						6,
						26,
						50,
						74
					],
					[
						6,
						30,
						54,
						78
					],
					[
						6,
						30,
						56,
						82
					],
					[
						6,
						30,
						58,
						86
					],
					[
						6,
						34,
						62,
						90
					],
					[
						6,
						28,
						50,
						72,
						94
					],
					[
						6,
						26,
						50,
						74,
						98
					],
					[
						6,
						30,
						54,
						78,
						102
					],
					[
						6,
						28,
						54,
						80,
						106
					],
					[
						6,
						32,
						58,
						84,
						110
					],
					[
						6,
						30,
						58,
						86,
						114
					],
					[
						6,
						34,
						62,
						90,
						118
					],
					[
						6,
						26,
						50,
						74,
						98,
						122
					],
					[
						6,
						30,
						54,
						78,
						102,
						126
					],
					[
						6,
						26,
						52,
						78,
						104,
						130
					],
					[
						6,
						30,
						56,
						82,
						108,
						134
					],
					[
						6,
						34,
						60,
						86,
						112,
						138
					],
					[
						6,
						30,
						58,
						86,
						114,
						142
					],
					[
						6,
						34,
						62,
						90,
						118,
						146
					],
					[
						6,
						30,
						54,
						78,
						102,
						126,
						150
					],
					[
						6,
						24,
						50,
						76,
						102,
						128,
						154
					],
					[
						6,
						28,
						54,
						80,
						106,
						132,
						158
					],
					[
						6,
						32,
						58,
						84,
						110,
						136,
						162
					],
					[
						6,
						26,
						54,
						82,
						110,
						138,
						166
					],
					[
						6,
						30,
						58,
						86,
						114,
						142,
						170
					]
				];
				var G15 = 1335;
				var G18 = 7973;
				var G15_MASK = 21522;
				var _this = {};
				var getBCHDigit = function(data) {
					var digit = 0;
					while (data != 0) {
						digit += 1;
						data >>>= 1;
					}
					return digit;
				};
				_this.getBCHTypeInfo = function(data) {
					var d = data << 10;
					while (getBCHDigit(d) - getBCHDigit(G15) >= 0) d ^= G15 << getBCHDigit(d) - getBCHDigit(G15);
					return (data << 10 | d) ^ G15_MASK;
				};
				_this.getBCHTypeNumber = function(data) {
					var d = data << 12;
					while (getBCHDigit(d) - getBCHDigit(G18) >= 0) d ^= G18 << getBCHDigit(d) - getBCHDigit(G18);
					return data << 12 | d;
				};
				_this.getPatternPosition = function(typeNumber) {
					return PATTERN_POSITION_TABLE[typeNumber - 1];
				};
				_this.getMaskFunction = function(maskPattern) {
					switch (maskPattern) {
						case QRMaskPattern.PATTERN000: return function(i, j) {
							return (i + j) % 2 == 0;
						};
						case QRMaskPattern.PATTERN001: return function(i, j) {
							return i % 2 == 0;
						};
						case QRMaskPattern.PATTERN010: return function(i, j) {
							return j % 3 == 0;
						};
						case QRMaskPattern.PATTERN011: return function(i, j) {
							return (i + j) % 3 == 0;
						};
						case QRMaskPattern.PATTERN100: return function(i, j) {
							return (Math.floor(i / 2) + Math.floor(j / 3)) % 2 == 0;
						};
						case QRMaskPattern.PATTERN101: return function(i, j) {
							return i * j % 2 + i * j % 3 == 0;
						};
						case QRMaskPattern.PATTERN110: return function(i, j) {
							return (i * j % 2 + i * j % 3) % 2 == 0;
						};
						case QRMaskPattern.PATTERN111: return function(i, j) {
							return (i * j % 3 + (i + j) % 2) % 2 == 0;
						};
						default: throw "bad maskPattern:" + maskPattern;
					}
				};
				_this.getErrorCorrectPolynomial = function(errorCorrectLength) {
					var a = qrPolynomial([1], 0);
					for (var i = 0; i < errorCorrectLength; i += 1) a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0));
					return a;
				};
				_this.getLengthInBits = function(mode, type) {
					if (1 <= type && type < 10) switch (mode) {
						case QRMode.MODE_NUMBER: return 10;
						case QRMode.MODE_ALPHA_NUM: return 9;
						case QRMode.MODE_8BIT_BYTE: return 8;
						case QRMode.MODE_KANJI: return 8;
						default: throw "mode:" + mode;
					}
					else if (type < 27) switch (mode) {
						case QRMode.MODE_NUMBER: return 12;
						case QRMode.MODE_ALPHA_NUM: return 11;
						case QRMode.MODE_8BIT_BYTE: return 16;
						case QRMode.MODE_KANJI: return 10;
						default: throw "mode:" + mode;
					}
					else if (type < 41) switch (mode) {
						case QRMode.MODE_NUMBER: return 14;
						case QRMode.MODE_ALPHA_NUM: return 13;
						case QRMode.MODE_8BIT_BYTE: return 16;
						case QRMode.MODE_KANJI: return 12;
						default: throw "mode:" + mode;
					}
					else throw "type:" + type;
				};
				_this.getLostPoint = function(qrcode) {
					var moduleCount = qrcode.getModuleCount();
					var lostPoint = 0;
					for (var row = 0; row < moduleCount; row += 1) for (var col = 0; col < moduleCount; col += 1) {
						var sameCount = 0;
						var dark = qrcode.isDark(row, col);
						for (var r = -1; r <= 1; r += 1) {
							if (row + r < 0 || moduleCount <= row + r) continue;
							for (var c = -1; c <= 1; c += 1) {
								if (col + c < 0 || moduleCount <= col + c) continue;
								if (r == 0 && c == 0) continue;
								if (dark == qrcode.isDark(row + r, col + c)) sameCount += 1;
							}
						}
						if (sameCount > 5) lostPoint += 3 + sameCount - 5;
					}
					for (var row = 0; row < moduleCount - 1; row += 1) for (var col = 0; col < moduleCount - 1; col += 1) {
						var count = 0;
						if (qrcode.isDark(row, col)) count += 1;
						if (qrcode.isDark(row + 1, col)) count += 1;
						if (qrcode.isDark(row, col + 1)) count += 1;
						if (qrcode.isDark(row + 1, col + 1)) count += 1;
						if (count == 0 || count == 4) lostPoint += 3;
					}
					for (var row = 0; row < moduleCount; row += 1) for (var col = 0; col < moduleCount - 6; col += 1) if (qrcode.isDark(row, col) && !qrcode.isDark(row, col + 1) && qrcode.isDark(row, col + 2) && qrcode.isDark(row, col + 3) && qrcode.isDark(row, col + 4) && !qrcode.isDark(row, col + 5) && qrcode.isDark(row, col + 6)) lostPoint += 40;
					for (var col = 0; col < moduleCount; col += 1) for (var row = 0; row < moduleCount - 6; row += 1) if (qrcode.isDark(row, col) && !qrcode.isDark(row + 1, col) && qrcode.isDark(row + 2, col) && qrcode.isDark(row + 3, col) && qrcode.isDark(row + 4, col) && !qrcode.isDark(row + 5, col) && qrcode.isDark(row + 6, col)) lostPoint += 40;
					var darkCount = 0;
					for (var col = 0; col < moduleCount; col += 1) for (var row = 0; row < moduleCount; row += 1) if (qrcode.isDark(row, col)) darkCount += 1;
					var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
					lostPoint += ratio * 10;
					return lostPoint;
				};
				return _this;
			}();
			var QRMath = function() {
				var EXP_TABLE = new Array(256);
				var LOG_TABLE = new Array(256);
				for (var i = 0; i < 8; i += 1) EXP_TABLE[i] = 1 << i;
				for (var i = 8; i < 256; i += 1) EXP_TABLE[i] = EXP_TABLE[i - 4] ^ EXP_TABLE[i - 5] ^ EXP_TABLE[i - 6] ^ EXP_TABLE[i - 8];
				for (var i = 0; i < 255; i += 1) LOG_TABLE[EXP_TABLE[i]] = i;
				var _this = {};
				_this.glog = function(n) {
					if (n < 1) throw "glog(" + n + ")";
					return LOG_TABLE[n];
				};
				_this.gexp = function(n) {
					while (n < 0) n += 255;
					while (n >= 256) n -= 255;
					return EXP_TABLE[n];
				};
				return _this;
			}();
			function qrPolynomial(num, shift) {
				if (typeof num.length == "undefined") throw num.length + "/" + shift;
				var _num = function() {
					var offset = 0;
					while (offset < num.length && num[offset] == 0) offset += 1;
					var _num = new Array(num.length - offset + shift);
					for (var i = 0; i < num.length - offset; i += 1) _num[i] = num[i + offset];
					return _num;
				}();
				var _this = {};
				_this.getAt = function(index) {
					return _num[index];
				};
				_this.getLength = function() {
					return _num.length;
				};
				_this.multiply = function(e) {
					var num = new Array(_this.getLength() + e.getLength() - 1);
					for (var i = 0; i < _this.getLength(); i += 1) for (var j = 0; j < e.getLength(); j += 1) num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i)) + QRMath.glog(e.getAt(j)));
					return qrPolynomial(num, 0);
				};
				_this.mod = function(e) {
					if (_this.getLength() - e.getLength() < 0) return _this;
					var ratio = QRMath.glog(_this.getAt(0)) - QRMath.glog(e.getAt(0));
					var num = new Array(_this.getLength());
					for (var i = 0; i < _this.getLength(); i += 1) num[i] = _this.getAt(i);
					for (var i = 0; i < e.getLength(); i += 1) num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i)) + ratio);
					return qrPolynomial(num, 0).mod(e);
				};
				return _this;
			}
			var QRRSBlock = function() {
				var RS_BLOCK_TABLE = [
					[
						1,
						26,
						19
					],
					[
						1,
						26,
						16
					],
					[
						1,
						26,
						13
					],
					[
						1,
						26,
						9
					],
					[
						1,
						44,
						34
					],
					[
						1,
						44,
						28
					],
					[
						1,
						44,
						22
					],
					[
						1,
						44,
						16
					],
					[
						1,
						70,
						55
					],
					[
						1,
						70,
						44
					],
					[
						2,
						35,
						17
					],
					[
						2,
						35,
						13
					],
					[
						1,
						100,
						80
					],
					[
						2,
						50,
						32
					],
					[
						2,
						50,
						24
					],
					[
						4,
						25,
						9
					],
					[
						1,
						134,
						108
					],
					[
						2,
						67,
						43
					],
					[
						2,
						33,
						15,
						2,
						34,
						16
					],
					[
						2,
						33,
						11,
						2,
						34,
						12
					],
					[
						2,
						86,
						68
					],
					[
						4,
						43,
						27
					],
					[
						4,
						43,
						19
					],
					[
						4,
						43,
						15
					],
					[
						2,
						98,
						78
					],
					[
						4,
						49,
						31
					],
					[
						2,
						32,
						14,
						4,
						33,
						15
					],
					[
						4,
						39,
						13,
						1,
						40,
						14
					],
					[
						2,
						121,
						97
					],
					[
						2,
						60,
						38,
						2,
						61,
						39
					],
					[
						4,
						40,
						18,
						2,
						41,
						19
					],
					[
						4,
						40,
						14,
						2,
						41,
						15
					],
					[
						2,
						146,
						116
					],
					[
						3,
						58,
						36,
						2,
						59,
						37
					],
					[
						4,
						36,
						16,
						4,
						37,
						17
					],
					[
						4,
						36,
						12,
						4,
						37,
						13
					],
					[
						2,
						86,
						68,
						2,
						87,
						69
					],
					[
						4,
						69,
						43,
						1,
						70,
						44
					],
					[
						6,
						43,
						19,
						2,
						44,
						20
					],
					[
						6,
						43,
						15,
						2,
						44,
						16
					],
					[
						4,
						101,
						81
					],
					[
						1,
						80,
						50,
						4,
						81,
						51
					],
					[
						4,
						50,
						22,
						4,
						51,
						23
					],
					[
						3,
						36,
						12,
						8,
						37,
						13
					],
					[
						2,
						116,
						92,
						2,
						117,
						93
					],
					[
						6,
						58,
						36,
						2,
						59,
						37
					],
					[
						4,
						46,
						20,
						6,
						47,
						21
					],
					[
						7,
						42,
						14,
						4,
						43,
						15
					],
					[
						4,
						133,
						107
					],
					[
						8,
						59,
						37,
						1,
						60,
						38
					],
					[
						8,
						44,
						20,
						4,
						45,
						21
					],
					[
						12,
						33,
						11,
						4,
						34,
						12
					],
					[
						3,
						145,
						115,
						1,
						146,
						116
					],
					[
						4,
						64,
						40,
						5,
						65,
						41
					],
					[
						11,
						36,
						16,
						5,
						37,
						17
					],
					[
						11,
						36,
						12,
						5,
						37,
						13
					],
					[
						5,
						109,
						87,
						1,
						110,
						88
					],
					[
						5,
						65,
						41,
						5,
						66,
						42
					],
					[
						5,
						54,
						24,
						7,
						55,
						25
					],
					[
						11,
						36,
						12,
						7,
						37,
						13
					],
					[
						5,
						122,
						98,
						1,
						123,
						99
					],
					[
						7,
						73,
						45,
						3,
						74,
						46
					],
					[
						15,
						43,
						19,
						2,
						44,
						20
					],
					[
						3,
						45,
						15,
						13,
						46,
						16
					],
					[
						1,
						135,
						107,
						5,
						136,
						108
					],
					[
						10,
						74,
						46,
						1,
						75,
						47
					],
					[
						1,
						50,
						22,
						15,
						51,
						23
					],
					[
						2,
						42,
						14,
						17,
						43,
						15
					],
					[
						5,
						150,
						120,
						1,
						151,
						121
					],
					[
						9,
						69,
						43,
						4,
						70,
						44
					],
					[
						17,
						50,
						22,
						1,
						51,
						23
					],
					[
						2,
						42,
						14,
						19,
						43,
						15
					],
					[
						3,
						141,
						113,
						4,
						142,
						114
					],
					[
						3,
						70,
						44,
						11,
						71,
						45
					],
					[
						17,
						47,
						21,
						4,
						48,
						22
					],
					[
						9,
						39,
						13,
						16,
						40,
						14
					],
					[
						3,
						135,
						107,
						5,
						136,
						108
					],
					[
						3,
						67,
						41,
						13,
						68,
						42
					],
					[
						15,
						54,
						24,
						5,
						55,
						25
					],
					[
						15,
						43,
						15,
						10,
						44,
						16
					],
					[
						4,
						144,
						116,
						4,
						145,
						117
					],
					[
						17,
						68,
						42
					],
					[
						17,
						50,
						22,
						6,
						51,
						23
					],
					[
						19,
						46,
						16,
						6,
						47,
						17
					],
					[
						2,
						139,
						111,
						7,
						140,
						112
					],
					[
						17,
						74,
						46
					],
					[
						7,
						54,
						24,
						16,
						55,
						25
					],
					[
						34,
						37,
						13
					],
					[
						4,
						151,
						121,
						5,
						152,
						122
					],
					[
						4,
						75,
						47,
						14,
						76,
						48
					],
					[
						11,
						54,
						24,
						14,
						55,
						25
					],
					[
						16,
						45,
						15,
						14,
						46,
						16
					],
					[
						6,
						147,
						117,
						4,
						148,
						118
					],
					[
						6,
						73,
						45,
						14,
						74,
						46
					],
					[
						11,
						54,
						24,
						16,
						55,
						25
					],
					[
						30,
						46,
						16,
						2,
						47,
						17
					],
					[
						8,
						132,
						106,
						4,
						133,
						107
					],
					[
						8,
						75,
						47,
						13,
						76,
						48
					],
					[
						7,
						54,
						24,
						22,
						55,
						25
					],
					[
						22,
						45,
						15,
						13,
						46,
						16
					],
					[
						10,
						142,
						114,
						2,
						143,
						115
					],
					[
						19,
						74,
						46,
						4,
						75,
						47
					],
					[
						28,
						50,
						22,
						6,
						51,
						23
					],
					[
						33,
						46,
						16,
						4,
						47,
						17
					],
					[
						8,
						152,
						122,
						4,
						153,
						123
					],
					[
						22,
						73,
						45,
						3,
						74,
						46
					],
					[
						8,
						53,
						23,
						26,
						54,
						24
					],
					[
						12,
						45,
						15,
						28,
						46,
						16
					],
					[
						3,
						147,
						117,
						10,
						148,
						118
					],
					[
						3,
						73,
						45,
						23,
						74,
						46
					],
					[
						4,
						54,
						24,
						31,
						55,
						25
					],
					[
						11,
						45,
						15,
						31,
						46,
						16
					],
					[
						7,
						146,
						116,
						7,
						147,
						117
					],
					[
						21,
						73,
						45,
						7,
						74,
						46
					],
					[
						1,
						53,
						23,
						37,
						54,
						24
					],
					[
						19,
						45,
						15,
						26,
						46,
						16
					],
					[
						5,
						145,
						115,
						10,
						146,
						116
					],
					[
						19,
						75,
						47,
						10,
						76,
						48
					],
					[
						15,
						54,
						24,
						25,
						55,
						25
					],
					[
						23,
						45,
						15,
						25,
						46,
						16
					],
					[
						13,
						145,
						115,
						3,
						146,
						116
					],
					[
						2,
						74,
						46,
						29,
						75,
						47
					],
					[
						42,
						54,
						24,
						1,
						55,
						25
					],
					[
						23,
						45,
						15,
						28,
						46,
						16
					],
					[
						17,
						145,
						115
					],
					[
						10,
						74,
						46,
						23,
						75,
						47
					],
					[
						10,
						54,
						24,
						35,
						55,
						25
					],
					[
						19,
						45,
						15,
						35,
						46,
						16
					],
					[
						17,
						145,
						115,
						1,
						146,
						116
					],
					[
						14,
						74,
						46,
						21,
						75,
						47
					],
					[
						29,
						54,
						24,
						19,
						55,
						25
					],
					[
						11,
						45,
						15,
						46,
						46,
						16
					],
					[
						13,
						145,
						115,
						6,
						146,
						116
					],
					[
						14,
						74,
						46,
						23,
						75,
						47
					],
					[
						44,
						54,
						24,
						7,
						55,
						25
					],
					[
						59,
						46,
						16,
						1,
						47,
						17
					],
					[
						12,
						151,
						121,
						7,
						152,
						122
					],
					[
						12,
						75,
						47,
						26,
						76,
						48
					],
					[
						39,
						54,
						24,
						14,
						55,
						25
					],
					[
						22,
						45,
						15,
						41,
						46,
						16
					],
					[
						6,
						151,
						121,
						14,
						152,
						122
					],
					[
						6,
						75,
						47,
						34,
						76,
						48
					],
					[
						46,
						54,
						24,
						10,
						55,
						25
					],
					[
						2,
						45,
						15,
						64,
						46,
						16
					],
					[
						17,
						152,
						122,
						4,
						153,
						123
					],
					[
						29,
						74,
						46,
						14,
						75,
						47
					],
					[
						49,
						54,
						24,
						10,
						55,
						25
					],
					[
						24,
						45,
						15,
						46,
						46,
						16
					],
					[
						4,
						152,
						122,
						18,
						153,
						123
					],
					[
						13,
						74,
						46,
						32,
						75,
						47
					],
					[
						48,
						54,
						24,
						14,
						55,
						25
					],
					[
						42,
						45,
						15,
						32,
						46,
						16
					],
					[
						20,
						147,
						117,
						4,
						148,
						118
					],
					[
						40,
						75,
						47,
						7,
						76,
						48
					],
					[
						43,
						54,
						24,
						22,
						55,
						25
					],
					[
						10,
						45,
						15,
						67,
						46,
						16
					],
					[
						19,
						148,
						118,
						6,
						149,
						119
					],
					[
						18,
						75,
						47,
						31,
						76,
						48
					],
					[
						34,
						54,
						24,
						34,
						55,
						25
					],
					[
						20,
						45,
						15,
						61,
						46,
						16
					]
				];
				var qrRSBlock = function(totalCount, dataCount) {
					var _this = {};
					_this.totalCount = totalCount;
					_this.dataCount = dataCount;
					return _this;
				};
				var _this = {};
				var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {
					switch (errorCorrectionLevel) {
						case QRErrorCorrectionLevel.L: return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
						case QRErrorCorrectionLevel.M: return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
						case QRErrorCorrectionLevel.Q: return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
						case QRErrorCorrectionLevel.H: return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
						default: return;
					}
				};
				_this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {
					var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
					if (typeof rsBlock == "undefined") throw "bad rs block @ typeNumber:" + typeNumber + "/errorCorrectionLevel:" + errorCorrectionLevel;
					var length = rsBlock.length / 3;
					var list = [];
					for (var i = 0; i < length; i += 1) {
						var count = rsBlock[i * 3 + 0];
						var totalCount = rsBlock[i * 3 + 1];
						var dataCount = rsBlock[i * 3 + 2];
						for (var j = 0; j < count; j += 1) list.push(qrRSBlock(totalCount, dataCount));
					}
					return list;
				};
				return _this;
			}();
			var qrBitBuffer = function() {
				var _buffer = [];
				var _length = 0;
				var _this = {};
				_this.getBuffer = function() {
					return _buffer;
				};
				_this.getAt = function(index) {
					return (_buffer[Math.floor(index / 8)] >>> 7 - index % 8 & 1) == 1;
				};
				_this.put = function(num, length) {
					for (var i = 0; i < length; i += 1) _this.putBit((num >>> length - i - 1 & 1) == 1);
				};
				_this.getLengthInBits = function() {
					return _length;
				};
				_this.putBit = function(bit) {
					var bufIndex = Math.floor(_length / 8);
					if (_buffer.length <= bufIndex) _buffer.push(0);
					if (bit) _buffer[bufIndex] |= 128 >>> _length % 8;
					_length += 1;
				};
				return _this;
			};
			var qrNumber = function(data) {
				var _mode = QRMode.MODE_NUMBER;
				var _data = data;
				var _this = {};
				_this.getMode = function() {
					return _mode;
				};
				_this.getLength = function(buffer) {
					return _data.length;
				};
				_this.write = function(buffer) {
					var data = _data;
					var i = 0;
					while (i + 2 < data.length) {
						buffer.put(strToNum(data.substring(i, i + 3)), 10);
						i += 3;
					}
					if (i < data.length) {
						if (data.length - i == 1) buffer.put(strToNum(data.substring(i, i + 1)), 4);
						else if (data.length - i == 2) buffer.put(strToNum(data.substring(i, i + 2)), 7);
					}
				};
				var strToNum = function(s) {
					var num = 0;
					for (var i = 0; i < s.length; i += 1) num = num * 10 + chatToNum(s.charAt(i));
					return num;
				};
				var chatToNum = function(c) {
					if ("0" <= c && c <= "9") return c.charCodeAt(0) - "0".charCodeAt(0);
					throw "illegal char :" + c;
				};
				return _this;
			};
			var qrAlphaNum = function(data) {
				var _mode = QRMode.MODE_ALPHA_NUM;
				var _data = data;
				var _this = {};
				_this.getMode = function() {
					return _mode;
				};
				_this.getLength = function(buffer) {
					return _data.length;
				};
				_this.write = function(buffer) {
					var s = _data;
					var i = 0;
					while (i + 1 < s.length) {
						buffer.put(getCode(s.charAt(i)) * 45 + getCode(s.charAt(i + 1)), 11);
						i += 2;
					}
					if (i < s.length) buffer.put(getCode(s.charAt(i)), 6);
				};
				var getCode = function(c) {
					if ("0" <= c && c <= "9") return c.charCodeAt(0) - "0".charCodeAt(0);
					else if ("A" <= c && c <= "Z") return c.charCodeAt(0) - "A".charCodeAt(0) + 10;
					else switch (c) {
						case " ": return 36;
						case "$": return 37;
						case "%": return 38;
						case "*": return 39;
						case "+": return 40;
						case "-": return 41;
						case ".": return 42;
						case "/": return 43;
						case ":": return 44;
						default: throw "illegal char :" + c;
					}
				};
				return _this;
			};
			var qr8BitByte = function(data) {
				var _mode = QRMode.MODE_8BIT_BYTE;
				var _bytes = qrcode.stringToBytes(data);
				var _this = {};
				_this.getMode = function() {
					return _mode;
				};
				_this.getLength = function(buffer) {
					return _bytes.length;
				};
				_this.write = function(buffer) {
					for (var i = 0; i < _bytes.length; i += 1) buffer.put(_bytes[i], 8);
				};
				return _this;
			};
			var qrKanji = function(data) {
				var _mode = QRMode.MODE_KANJI;
				var stringToBytes = qrcode.stringToBytesFuncs["SJIS"];
				if (!stringToBytes) throw "sjis not supported.";
				(function(c, code) {
					var test = stringToBytes(c);
					if (test.length != 2 || (test[0] << 8 | test[1]) != code) throw "sjis not supported.";
				})("友", 38726);
				var _bytes = stringToBytes(data);
				var _this = {};
				_this.getMode = function() {
					return _mode;
				};
				_this.getLength = function(buffer) {
					return ~~(_bytes.length / 2);
				};
				_this.write = function(buffer) {
					var data = _bytes;
					var i = 0;
					while (i + 1 < data.length) {
						var c = (255 & data[i]) << 8 | 255 & data[i + 1];
						if (33088 <= c && c <= 40956) c -= 33088;
						else if (57408 <= c && c <= 60351) c -= 49472;
						else throw "illegal char at " + (i + 1) + "/" + c;
						c = (c >>> 8 & 255) * 192 + (c & 255);
						buffer.put(c, 13);
						i += 2;
					}
					if (i < data.length) throw "illegal char at " + (i + 1);
				};
				return _this;
			};
			var byteArrayOutputStream = function() {
				var _bytes = [];
				var _this = {};
				_this.writeByte = function(b) {
					_bytes.push(b & 255);
				};
				_this.writeShort = function(i) {
					_this.writeByte(i);
					_this.writeByte(i >>> 8);
				};
				_this.writeBytes = function(b, off, len) {
					off = off || 0;
					len = len || b.length;
					for (var i = 0; i < len; i += 1) _this.writeByte(b[i + off]);
				};
				_this.writeString = function(s) {
					for (var i = 0; i < s.length; i += 1) _this.writeByte(s.charCodeAt(i));
				};
				_this.toByteArray = function() {
					return _bytes;
				};
				_this.toString = function() {
					var s = "";
					s += "[";
					for (var i = 0; i < _bytes.length; i += 1) {
						if (i > 0) s += ",";
						s += _bytes[i];
					}
					s += "]";
					return s;
				};
				return _this;
			};
			var base64EncodeOutputStream = function() {
				var _buffer = 0;
				var _buflen = 0;
				var _length = 0;
				var _base64 = "";
				var _this = {};
				var writeEncoded = function(b) {
					_base64 += String.fromCharCode(encode(b & 63));
				};
				var encode = function(n) {
					if (n < 0) {} else if (n < 26) return 65 + n;
					else if (n < 52) return 97 + (n - 26);
					else if (n < 62) return 48 + (n - 52);
					else if (n == 62) return 43;
					else if (n == 63) return 47;
					throw "n:" + n;
				};
				_this.writeByte = function(n) {
					_buffer = _buffer << 8 | n & 255;
					_buflen += 8;
					_length += 1;
					while (_buflen >= 6) {
						writeEncoded(_buffer >>> _buflen - 6);
						_buflen -= 6;
					}
				};
				_this.flush = function() {
					if (_buflen > 0) {
						writeEncoded(_buffer << 6 - _buflen);
						_buffer = 0;
						_buflen = 0;
					}
					if (_length % 3 != 0) {
						var padlen = 3 - _length % 3;
						for (var i = 0; i < padlen; i += 1) _base64 += "=";
					}
				};
				_this.toString = function() {
					return _base64;
				};
				return _this;
			};
			var base64DecodeInputStream = function(str) {
				var _str = str;
				var _pos = 0;
				var _buffer = 0;
				var _buflen = 0;
				var _this = {};
				_this.read = function() {
					while (_buflen < 8) {
						if (_pos >= _str.length) {
							if (_buflen == 0) return -1;
							throw "unexpected end of file./" + _buflen;
						}
						var c = _str.charAt(_pos);
						_pos += 1;
						if (c == "=") {
							_buflen = 0;
							return -1;
						} else if (c.match(/^\s$/)) continue;
						_buffer = _buffer << 6 | decode(c.charCodeAt(0));
						_buflen += 6;
					}
					var n = _buffer >>> _buflen - 8 & 255;
					_buflen -= 8;
					return n;
				};
				var decode = function(c) {
					if (65 <= c && c <= 90) return c - 65;
					else if (97 <= c && c <= 122) return c - 97 + 26;
					else if (48 <= c && c <= 57) return c - 48 + 52;
					else if (c == 43) return 62;
					else if (c == 47) return 63;
					else throw "c:" + c;
				};
				return _this;
			};
			var gifImage = function(width, height) {
				var _width = width;
				var _height = height;
				var _data = new Array(width * height);
				var _this = {};
				_this.setPixel = function(x, y, pixel) {
					_data[y * _width + x] = pixel;
				};
				_this.write = function(out) {
					out.writeString("GIF87a");
					out.writeShort(_width);
					out.writeShort(_height);
					out.writeByte(128);
					out.writeByte(0);
					out.writeByte(0);
					out.writeByte(0);
					out.writeByte(0);
					out.writeByte(0);
					out.writeByte(255);
					out.writeByte(255);
					out.writeByte(255);
					out.writeString(",");
					out.writeShort(0);
					out.writeShort(0);
					out.writeShort(_width);
					out.writeShort(_height);
					out.writeByte(0);
					var lzwMinCodeSize = 2;
					var raster = getLZWRaster(lzwMinCodeSize);
					out.writeByte(lzwMinCodeSize);
					var offset = 0;
					while (raster.length - offset > 255) {
						out.writeByte(255);
						out.writeBytes(raster, offset, 255);
						offset += 255;
					}
					out.writeByte(raster.length - offset);
					out.writeBytes(raster, offset, raster.length - offset);
					out.writeByte(0);
					out.writeString(";");
				};
				var bitOutputStream = function(out) {
					var _out = out;
					var _bitLength = 0;
					var _bitBuffer = 0;
					var _this = {};
					_this.write = function(data, length) {
						if (data >>> length != 0) throw "length over";
						while (_bitLength + length >= 8) {
							_out.writeByte(255 & (data << _bitLength | _bitBuffer));
							length -= 8 - _bitLength;
							data >>>= 8 - _bitLength;
							_bitBuffer = 0;
							_bitLength = 0;
						}
						_bitBuffer = data << _bitLength | _bitBuffer;
						_bitLength = _bitLength + length;
					};
					_this.flush = function() {
						if (_bitLength > 0) _out.writeByte(_bitBuffer);
					};
					return _this;
				};
				var getLZWRaster = function(lzwMinCodeSize) {
					var clearCode = 1 << lzwMinCodeSize;
					var endCode = (1 << lzwMinCodeSize) + 1;
					var bitLength = lzwMinCodeSize + 1;
					var table = lzwTable();
					for (var i = 0; i < clearCode; i += 1) table.add(String.fromCharCode(i));
					table.add(String.fromCharCode(clearCode));
					table.add(String.fromCharCode(endCode));
					var byteOut = byteArrayOutputStream();
					var bitOut = bitOutputStream(byteOut);
					bitOut.write(clearCode, bitLength);
					var dataIndex = 0;
					var s = String.fromCharCode(_data[dataIndex]);
					dataIndex += 1;
					while (dataIndex < _data.length) {
						var c = String.fromCharCode(_data[dataIndex]);
						dataIndex += 1;
						if (table.contains(s + c)) s = s + c;
						else {
							bitOut.write(table.indexOf(s), bitLength);
							if (table.size() < 4095) {
								if (table.size() == 1 << bitLength) bitLength += 1;
								table.add(s + c);
							}
							s = c;
						}
					}
					bitOut.write(table.indexOf(s), bitLength);
					bitOut.write(endCode, bitLength);
					bitOut.flush();
					return byteOut.toByteArray();
				};
				var lzwTable = function() {
					var _map = {};
					var _size = 0;
					var _this = {};
					_this.add = function(key) {
						if (_this.contains(key)) throw "dup key:" + key;
						_map[key] = _size;
						_size += 1;
					};
					_this.size = function() {
						return _size;
					};
					_this.indexOf = function(key) {
						return _map[key];
					};
					_this.contains = function(key) {
						return typeof _map[key] != "undefined";
					};
					return _this;
				};
				return _this;
			};
			var createDataURL = function(width, height, getPixel) {
				var gif = gifImage(width, height);
				for (var y = 0; y < height; y += 1) for (var x = 0; x < width; x += 1) gif.setPixel(x, y, getPixel(x, y));
				var b = byteArrayOutputStream();
				gif.write(b);
				var base64 = base64EncodeOutputStream();
				var bytes = b.toByteArray();
				for (var i = 0; i < bytes.length; i += 1) base64.writeByte(bytes[i]);
				base64.flush();
				return "data:image/gif;base64," + base64;
			};
			return qrcode;
		}();
		(function() {
			qrcode.stringToBytesFuncs["UTF-8"] = function(s) {
				function toUTF8Array(str) {
					var utf8 = [];
					for (var i = 0; i < str.length; i++) {
						var charcode = str.charCodeAt(i);
						if (charcode < 128) utf8.push(charcode);
						else if (charcode < 2048) utf8.push(192 | charcode >> 6, 128 | charcode & 63);
						else if (charcode < 55296 || charcode >= 57344) utf8.push(224 | charcode >> 12, 128 | charcode >> 6 & 63, 128 | charcode & 63);
						else {
							i++;
							charcode = 65536 + ((charcode & 1023) << 10 | str.charCodeAt(i) & 1023);
							utf8.push(240 | charcode >> 18, 128 | charcode >> 12 & 63, 128 | charcode >> 6 & 63, 128 | charcode & 63);
						}
					}
					return utf8;
				}
				return toUTF8Array(s);
			};
		})();
		const createQrCode = qrcode;
		/**
		* Encode text as a QR matrix.
		* @param text - content to encode (byte mode).
		* @param level - error-correction level; defaults to M.
		* @returns the module matrix, quiet zone excluded.
		* @throws when the text does not fit in a version-40 symbol.
		*/
		function qrMatrix(text, level = "M") {
			const qr = createQrCode(0, level);
			qr.addData(text, "Byte");
			qr.make();
			const size = qr.getModuleCount();
			const modules = [];
			for (let row = 0; row < size; row += 1) {
				const line = [];
				for (let column = 0; column < size; column += 1) line.push(qr.isDark(row, column));
				modules.push(line);
			}
			return {
				size,
				modules
			};
		}
		/**
		* Build SVG path data for a matrix, one merged horizontal run per dark span.
		*
		* Runs rather than per-module squares keep the attribute small enough that the
		* whole code stays a single node.
		* @param matrix - modules to draw.
		* @param quietZone - quiet zone in modules to offset by.
		* @returns path data in module units.
		*/
		function qrPathData(matrix, quietZone = 4) {
			const parts = [];
			for (let row = 0; row < matrix.size; row += 1) {
				const line = matrix.modules[row] ?? [];
				let column = 0;
				while (column < matrix.size) {
					if (line[column] !== true) {
						column += 1;
						continue;
					}
					let run = 1;
					while (column + run < matrix.size && line[column + run] === true) run += 1;
					parts.push(`M${String(column + quietZone)} ${String(row + quietZone)}h${String(run)}v1h-${String(run)}z`);
					column += run;
				}
			}
			return parts.join("");
		}
		/**
		* Side length in module units of the drawn symbol, quiet zone included.
		* @param matrix - encoded modules.
		* @param quietZone - quiet zone in modules.
		* @returns the viewBox side length.
		*/
		function qrViewBoxSize(matrix, quietZone = 4) {
			return matrix.size + quietZone * 2;
		}
		//#endregion
		//#region src/client/qr-code.tsx
		/**
		* The QR code as an SVG node.
		*
		* The surface is deliberately fixed light-on-dark-independently: inverting a QR
		* code (light modules on a dark card) is what stops phone cameras from reading
		* it, so this element does not consume theme tokens.
		* @module @harlin97/dsh-ipad-remote/client/qr-code
		*/
		/** Module ink. */
		const DARK = "#000000";
		/** Card behind the code — both the quiet zone and the modules need it. */
		const LIGHT = "#ffffff";
		/**
		* Render an address as a scannable code.
		* @param props.text - content to encode, normally the address URL.
		* @param props.label - accessible name (the code itself is not readable text).
		* @param props.size - rendered edge length in CSS pixels.
		* @param props.level - error-correction level; defaults to M.
		* @returns the SVG element.
		*/
		function QrCode({ text, label, size = 148, level = "M" }) {
			const matrix = (0, react.useMemo)(() => qrMatrix(text, level), [text, level]);
			const view = qrViewBoxSize(matrix);
			return (0, react.createElement)("svg", {
				width: size,
				height: size,
				viewBox: `0 0 ${String(view)} ${String(view)}`,
				role: "img",
				"aria-label": label,
				shapeRendering: "crispEdges",
				style: {
					display: "block",
					flex: "0 0 auto",
					borderRadius: "8px",
					background: LIGHT
				}
			}, [(0, react.createElement)("rect", {
				key: "surface",
				x: 0,
				y: 0,
				width: view,
				height: view,
				fill: LIGHT
			}), (0, react.createElement)("path", {
				key: "modules",
				d: qrPathData(matrix),
				fill: DARK
			})]);
		}
		//#endregion
		//#region src/client/section.tsx
		/**
		* "PWA remote access" — the settings section body.
		*
		* One place to switch the gateway on or off, set the access PIN, read the
		* addresses an iPad can open (with a scannable code each), and revoke every
		* unlocked device. Everything it renders comes from the loopback control
		* surface via {@link ControlApi}; nothing here reaches the network gateway.
		*
		* Written with `createElement` rather than JSX so the browser bundle needs no
		* JSX transform — the same shape the reference client plugin uses.
		* @module @harlin97/dsh-ipad-remote/client/section
		*/
		/** How often a mounted section re-reads the host status. */
		const REFRESH_MS = 5e3;
		/** How long the armed revoke confirmation waits for its second press. */
		const CONFIRM_MS = 5e3;
		/** Rendered edge length of an address code, in CSS pixels. */
		const QR_SIZE = 148;
		/**
		* Section-local layout. Surfaces stay on the page layer — only the code itself
		* gets a card, because a scanner needs the light quiet zone around it.
		*/
		const S = {
			root: {
				display: "flex",
				flexDirection: "column",
				gap: "4px",
				maxWidth: "760px",
				fontSize: "13px",
				lineHeight: "20px",
				color: "var(--dsw-alias-label-primary)"
			},
			intro: {
				margin: "0 0 10px",
				fontSize: "13px",
				color: "var(--dsw-alias-label-secondary)"
			},
			block: {
				display: "flex",
				flexDirection: "column",
				gap: "10px",
				padding: "14px 0",
				borderTop: "1px solid var(--dsw-alias-border-l2)"
			},
			blockTitle: {
				margin: 0,
				fontSize: "14px",
				fontWeight: 600,
				color: "var(--dsw-alias-label-primary)"
			},
			row: {
				display: "flex",
				alignItems: "center",
				gap: "12px",
				minWidth: 0
			},
			grow: {
				display: "flex",
				flexDirection: "column",
				gap: "4px",
				minWidth: 0,
				flex: "1 1 auto"
			},
			label: {
				display: "flex",
				alignItems: "center",
				gap: "8px",
				flexWrap: "wrap",
				fontWeight: 500
			},
			hint: {
				margin: 0,
				fontSize: "12px",
				lineHeight: "18px",
				color: "var(--dsw-alias-label-secondary)",
				overflowWrap: "anywhere"
			},
			mono: {
				fontFamily: "var(--ds-font-family-code)",
				fontSize: "12px",
				overflowWrap: "anywhere"
			},
			addresses: {
				display: "flex",
				flexDirection: "column",
				gap: "14px"
			},
			addressRow: {
				display: "flex",
				gap: "14px",
				alignItems: "flex-start",
				flexWrap: "wrap"
			},
			list: {
				display: "flex",
				flexDirection: "column",
				gap: "8px",
				margin: 0,
				padding: 0,
				listStyle: "none"
			},
			item: {
				display: "flex",
				flexDirection: "column",
				gap: "2px",
				minWidth: 0,
				overflowWrap: "anywhere"
			},
			pinRow: {
				display: "flex",
				gap: "8px",
				alignItems: "center",
				flexWrap: "wrap"
			},
			pinInput: { width: "9rem" },
			actions: {
				display: "flex",
				gap: "8px",
				alignItems: "center",
				flexWrap: "wrap"
			},
			footer: {
				display: "flex",
				gap: "8px",
				alignItems: "center",
				justifyContent: "space-between",
				flexWrap: "wrap",
				paddingTop: "14px",
				borderTop: "1px solid var(--dsw-alias-border-l2)"
			},
			error: {
				margin: 0,
				fontSize: "12px",
				lineHeight: "18px",
				color: "var(--dsw-alias-state-error-primary)",
				overflowWrap: "anywhere"
			},
			dangerButton: {
				color: "var(--dsw-alias-state-error-primary)",
				borderColor: "var(--dsw-alias-state-error-primary)"
			}
		};
		/**
		* Render an ISO timestamp in the viewer's locale.
		* @param iso - ISO-8601 string from the host.
		* @returns a local date-time, or the raw value when it is not parseable.
		*/
		function formatTime(iso) {
			const value = new Date(iso);
			return Number.isNaN(value.getTime()) ? iso : value.toLocaleString();
		}
		/**
		* The remote-access settings page.
		* @param props.t - localized copy.
		* @param props.api - control client override.
		* @returns the section element.
		*/
		function IpadRemoteSection({ t, api }) {
			const client = (0, react.useMemo)(() => api ?? createControlApi(), [api]);
			const [view, setView] = (0, react.useState)({ phase: "loading" });
			const [busy, setBusy] = (0, react.useState)(null);
			const [actionError, setActionError] = (0, react.useState)(null);
			const [stale, setStale] = (0, react.useState)(false);
			const [pin, setPin] = (0, react.useState)("");
			const [pinTouched, setPinTouched] = (0, react.useState)(false);
			const [confirmingRevoke, setConfirmingRevoke] = (0, react.useState)(false);
			const [showPin, setShowPin] = (0, react.useState)(false);
			const [toast, setToast] = (0, react.useState)(null);
			const busyRef = (0, react.useRef)(null);
			const showToast = (0, react.useCallback)((text) => {
				setToast((current) => ({
					text,
					seq: (current?.seq ?? 0) + 1
				}));
			}, []);
			const load = (0, react.useCallback)(async (silent) => {
				try {
					const status = await client.status();
					setView({
						phase: "ready",
						status
					});
					setStale(false);
				} catch (error) {
					if (silent) {
						setStale(true);
						return;
					}
					setView({
						phase: "failed",
						message: messageOf(error)
					});
				}
			}, [client]);
			(0, react.useEffect)(() => {
				load(false);
			}, [load]);
			(0, react.useEffect)(() => {
				const timer = setInterval(() => {
					if (busyRef.current === null) load(true);
				}, REFRESH_MS);
				return () => {
					clearInterval(timer);
				};
			}, [load]);
			(0, react.useEffect)(() => {
				if (!confirmingRevoke) return void 0;
				const timer = setTimeout(() => {
					setConfirmingRevoke(false);
				}, CONFIRM_MS);
				return () => {
					clearTimeout(timer);
				};
			}, [confirmingRevoke]);
			/**
			* Run one write, then refresh from the host's real answer.
			* @param name - in-flight marker shown by disabled controls.
			* @param action - the control call.
			* @param success - toast copy on success.
			* @returns whether the write succeeded.
			*/
			const run = (0, react.useCallback)(async (name, action, success) => {
				busyRef.current = name;
				setBusy(name);
				setActionError(null);
				try {
					const status = await action();
					setView({
						phase: "ready",
						status
					});
					setStale(false);
					if (success !== void 0) showToast(success);
					return true;
				} catch (error) {
					setActionError(messageOf(error));
					return false;
				} finally {
					busyRef.current = null;
					setBusy(null);
				}
			}, [showToast]);
			const status = view.phase === "ready" ? view.status : void 0;
			const busyNow = busy !== null;
			const pinValid = isValidPinFormat(pin);
			const showPinError = pinTouched && pin !== "" && !pinValid;
			const onToggle = (next) => {
				run("enable", () => client.setEnabled(next), next ? t("enabledToast") : t("disabledToast"));
			};
			const onSavePin = () => {
				setPinTouched(true);
				if (!pinValid) return;
				run("pin", () => client.setPin(pin), t("pinSaved")).then((saved) => {
					if (saved) {
						setPin("");
						setPinTouched(false);
					}
				});
			};
			const onRevoke = () => {
				if (!confirmingRevoke) {
					setConfirmingRevoke(true);
					return;
				}
				setConfirmingRevoke(false);
				run("revoke", () => client.revoke(), t("revoked"));
			};
			const onCopy = (url) => {
				const clipboard = globalThis.navigator?.clipboard;
				if (clipboard === void 0) {
					setActionError(t("copyFailed"));
					return;
				}
				clipboard.writeText(url).then(() => {
					showToast(t("copied"));
				}, () => {
					setActionError(t("copyFailed"));
				});
			};
			const stateTag = status === void 0 ? null : !status.enabled ? {
				tone: "quiet",
				text: t("stopped")
			} : status.listening ? {
				tone: "success",
				text: t("listening")
			} : {
				tone: "danger",
				text: t("portBusy")
			};
			return (0, react.createElement)("div", { style: S.root }, (0, react.createElement)("p", { style: S.intro }, t("intro")), stale ? (0, react.createElement)("p", {
				style: S.error,
				role: "status"
			}, t("staleWarning")) : null, view.phase === "loading" ? (0, react.createElement)("p", {
				style: S.hint,
				role: "status"
			}, t("loading")) : null, view.phase === "failed" ? (0, react.createElement)("div", { style: S.block }, (0, react.createElement)("p", {
				style: S.error,
				role: "alert"
			}, `${t("loadFailed")}：${view.message}`), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				size: "sm",
				variant: "outline",
				onClick: () => {
					load(false);
				}
			}, t("retry"))) : null, status === void 0 ? null : (0, react.createElement)("div", { style: S.block }, (0, react.createElement)("h3", { style: S.blockTitle }, t("enableLabel")), (0, react.createElement)("div", { style: S.row }, (0, react.createElement)("div", { style: S.grow }, (0, react.createElement)("div", { style: S.label }, stateTag === null ? null : (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Tag, { tone: stateTag.tone }, stateTag.text)), (0, react.createElement)("p", { style: S.hint }, status.enabled && !status.listening ? t("portBusyHint") : t("enableHint"))), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Switch, {
				checked: status.enabled,
				disabled: busyNow,
				label: t("enableLabel"),
				onChange: onToggle
			}))), status === void 0 ? null : (0, react.createElement)("div", { style: S.block }, (0, react.createElement)("h3", { style: S.blockTitle }, t("pinTitle")), (0, react.createElement)("div", { style: S.label }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Tag, { tone: status.hasPin ? "success" : "warning" }, status.hasPin ? t("pinSet") : t("pinUnset"))), status.currentPin === void 0 ? status.hasPin ? (0, react.createElement)("p", { style: S.hint }, t("pinUnknown")) : null : (0, react.createElement)("div", { style: S.pinRow }, (0, react.createElement)("span", { style: S.hint }, t("pinCurrent")), (0, react.createElement)("code", { style: S.mono }, showPin ? status.currentPin : "••••••"), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				disabled: busyNow,
				onClick: () => {
					setShowPin((value) => !value);
				}
			}, showPin ? t("pinHide") : t("pinReveal"))), (0, react.createElement)("div", { style: S.pinRow }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Input, {
				type: "password",
				inputMode: "numeric",
				autoComplete: "off",
				maxLength: 6,
				value: pin,
				placeholder: t("pinPlaceholder"),
				"aria-label": t("pinLabel"),
				"aria-invalid": showPinError,
				disabled: busyNow,
				style: S.pinInput,
				onChange: (event) => {
					setPin(event.target.value.replace(/[^0-9]/g, ""));
					setPinTouched(true);
				}
			}), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				variant: "primary",
				disabled: busyNow || !pinValid,
				onClick: onSavePin
			}, t("pinSave"))), showPinError ? (0, react.createElement)("p", {
				style: S.error,
				role: "alert"
			}, t("pinInvalid")) : null, (0, react.createElement)("p", { style: S.hint }, t("pinHint"))), status === void 0 ? null : (0, react.createElement)("div", { style: S.block }, (0, react.createElement)("h3", { style: S.blockTitle }, t("addressesTitle")), status.addresses.length === 0 ? (0, react.createElement)("p", { style: S.hint }, t("addressesEmpty")) : (0, react.createElement)("div", { style: S.addresses }, ...status.addresses.map((entry) => (0, react.createElement)("div", {
				key: entry.url,
				style: S.addressRow
			}, (0, react.createElement)("div", { style: S.grow }, (0, react.createElement)("div", { style: S.label }, entry.label, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Tag, { tone: "outline" }, entry.iface)), (0, react.createElement)("div", { style: S.mono }, entry.url), (0, react.createElement)("div", null, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				size: "sm",
				variant: "outline",
				"aria-label": `${t("copy")}：${entry.url}`,
				onClick: () => {
					onCopy(entry.url);
				}
			}, t("copy")))), (0, react.createElement)(QrCode, {
				text: entry.url,
				label: `${t("qrLabel")}：${entry.url}`,
				size: QR_SIZE
			})))), (0, react.createElement)("p", { style: S.hint }, t("addressesHint"))), status === void 0 ? null : (0, react.createElement)("div", { style: S.block }, (0, react.createElement)("h3", { style: S.blockTitle }, t("sessionsTitle")), status.sessions.length === 0 ? (0, react.createElement)("p", { style: S.hint }, t("sessionsEmpty")) : (0, react.createElement)("ul", { style: S.list }, ...status.sessions.map((session, index) => (0, react.createElement)("li", {
				key: `${session.issuedAt}-${String(index)}`,
				style: S.item
			}, (0, react.createElement)("span", null, session.label), (0, react.createElement)("span", { style: S.hint }, `${t("issuedAt")} ${formatTime(session.issuedAt)} · ${t("expiresAt")} ${formatTime(session.expiresAt)}`)))), status.sessions.length === 0 ? null : (0, react.createElement)("div", { style: S.actions }, (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				size: "sm",
				variant: "outline",
				style: confirmingRevoke ? S.dangerButton : void 0,
				disabled: busyNow,
				onClick: onRevoke
			}, confirmingRevoke ? t("revokeConfirm") : t("revoke")))), actionError === null ? null : (0, react.createElement)("p", {
				style: S.error,
				role: "alert"
			}, `${t("actionFailed")}：${actionError}`), status === void 0 ? null : (0, react.createElement)("div", { style: S.footer }, (0, react.createElement)("span", { style: S.hint }, `${t("storePath")}：${status.storePath}`), (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Button, {
				size: "sm",
				variant: "ghost",
				disabled: busyNow,
				onClick: () => {
					load(false);
				}
			}, t("refresh"))), toast === null ? null : (0, react.createElement)(_deepseek_ai_dsh_client_ui_primitives.Toast, {
				key: toast.seq,
				text: toast.text,
				tone: "success",
				onDone: () => {
					setToast(null);
				}
			}));
		}
		//#endregion
		//#region src/client/locales.ts
		/**
		* Copy for the remote-access settings section.
		*
		* Both dictionaries are complete records of the same key union, so adding a
		* key without translating it fails the type check rather than shipping a
		* half-translated page.
		* @module @harlin97/dsh-ipad-remote/client/locales
		*/
		/** Chinese dictionary — the source of the key union. */
		const zh = {
			nav: "PWA 远程访问",
			intro: "开启后，同一局域网或 Tailscale 网络里的设备可以打开这个 Harness 的同一个界面，入口由这个 PIN 把守。",
			enableLabel: "允许远程访问",
			enableHint: "关闭只停止监听，PIN 与配置都会保留。",
			listening: "监听中",
			stopped: "已停止",
			portBusy: "端口被占用",
			portBusyHint: "开关是打开的，但端口没能监听成功——通常是被别的程序占着。换端口或关掉占用者后重试。",
			enabledToast: "远程访问已开启",
			disabledToast: "远程访问已停止",
			pinTitle: "访问 PIN",
			pinCurrent: "当前 PIN",
			pinReveal: "显示",
			pinHide: "隐藏",
			pinUnknown: "本次运行内还没设置过 PIN，无法显示——磁盘上只保存不可逆校验子，重设一次就能看到。",
			pinLabel: "6 位数字 PIN",
			pinPlaceholder: "6 位数字",
			pinSet: "已设置",
			pinUnset: "未设置",
			pinSave: "设置 PIN",
			pinInvalid: "PIN 必须是 6 位数字。",
			pinSaved: "PIN 已更新",
			pinHint: "设备第一次打开时需要输入这个 PIN。本页只在本次运行内能显示你设置过的 PIN（不落盘）；改 PIN 不会踢掉已经解锁的设备——要踢掉请用下面的「全部撤销」。",
			addressesTitle: "在设备上打开",
			addressesHint: "用手机相机扫描二维码，或手动输入下面的地址。",
			addressesEmpty: "还没有可用的地址：本机没有已启用的网络接口。",
			copy: "复制",
			copied: "地址已复制",
			copyFailed: "复制失败，请手动选择地址",
			qrLabel: "地址二维码",
			sessionsTitle: "已解锁的设备",
			sessionsEmpty: "还没有设备解锁。",
			revoke: "全部撤销",
			revokeConfirm: "确认全部撤销",
			revoked: "已撤销全部设备",
			issuedAt: "解锁于",
			expiresAt: "有效期至",
			storePath: "状态文件",
			refresh: "刷新",
			loading: "正在读取状态…",
			loadFailed: "读取状态失败",
			retry: "重试",
			staleWarning: "后台刷新失败，下面是上一次成功读取的状态。",
			actionFailed: "操作失败"
		};
		/** English dictionary. */
		const en = {
			nav: "PWA Remote Access",
			intro: "Once enabled, a device on the same LAN or Tailscale network can open this very Harness UI; the PIN below guards the entrance.",
			enableLabel: "Allow remote access",
			enableHint: "Turning this off only stops the listener; the PIN and configuration are kept.",
			listening: "Listening",
			stopped: "Stopped",
			portBusy: "Port unavailable",
			portBusyHint: "The switch is on, but the port could not be bound — usually another program holds it. Free the port and retry.",
			enabledToast: "Remote access enabled",
			disabledToast: "Remote access stopped",
			pinTitle: "Access PIN",
			pinCurrent: "Current PIN",
			pinReveal: "Show",
			pinHide: "Hide",
			pinUnknown: "No PIN has been set in this run, so there is nothing to show — only an irreversible verifier is stored. Set it once to reveal it.",
			pinLabel: "Six-digit PIN",
			pinPlaceholder: "6 digits",
			pinSet: "Set",
			pinUnset: "Not set",
			pinSave: "Set PIN",
			pinInvalid: "The PIN must be exactly six digits.",
			pinSaved: "PIN updated",
			pinHint: "A device asks for this PIN the first time it opens the address. This page can reveal a PIN only within the run that set it, and never writes it to disk. Changing it does not disconnect devices that already unlocked — use Revoke all below for that.",
			addressesTitle: "Open on a device",
			addressesHint: "Scan a code with a phone camera, or type the address below.",
			addressesEmpty: "No address yet: this machine has no enabled network interface.",
			copy: "Copy",
			copied: "Address copied",
			copyFailed: "Copy failed — select the address manually",
			qrLabel: "Address QR code",
			sessionsTitle: "Unlocked devices",
			sessionsEmpty: "No device has unlocked yet.",
			revoke: "Revoke all",
			revokeConfirm: "Confirm revoke all",
			revoked: "All devices revoked",
			issuedAt: "Unlocked",
			expiresAt: "Expires",
			storePath: "State file",
			refresh: "Refresh",
			loading: "Reading status…",
			loadFailed: "Could not read status",
			retry: "Retry",
			staleWarning: "Background refresh failed; this is the last status read successfully.",
			actionFailed: "Operation failed"
		};
		//#endregion
		//#region src/client/settings.tsx
		/** Stable client-plugin name; matches the Host half and the package name. */
		const name = "ipad-remote";
		/** Services this half needs before it may register anything. */
		const inject = ["slots", "locale"];
		/** Locale namespace owning every string this section renders. */
		const NS = "ipad-remote";
		/** Navigation position: after the feature sections, before plugin inventory. */
		const SECTION_ORDER = 60;
		/**
		* Register the section and its dictionaries.
		* @param ctx - owning client plugin context.
		*/
		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(NS, {
				zh,
				en
			}), "ipad-remote: dictionaries");
			installDirectoryFlow(ctx);
			const t = ctx.locale.bind(NS);
			ctx.slots.inject("settings.section", () => ctx.slots.register({
				name: "settings.section",
				id: "ipad-remote",
				order: SECTION_ORDER,
				label: () => t("nav"),
				locale: NS,
				inject: () => ({ t })
			}, IpadRemoteSection));
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		exports.name = name;
		return module.exports;
	}
});

//# sourceMappingURL=settings.js.map